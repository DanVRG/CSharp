﻿using System;
using System.Collections.Generic;
using System.Text;

namespace zh
{
    class Engiszik
    {
        private int id;
        private string type;
        private int moodLevel;
        private int xPos;
        private int yPos;

        public Engiszik(int id, string type, int moodLevel, int xPos, int yPos)
        {
            this.type = type;
            this.moodLevel = moodLevel;
            this.xPos = xPos;
            this.yPos = yPos;
        }

        public string getType()
        {
            return type;
        }

        public int getID()
        {
            return id;
        }

        public int getMoodLevel()
        {
            return moodLevel;
        }

        public void setMoodLevel(int newMoodLevel)
        {
            moodLevel = newMoodLevel;
        }

        public int getXPos()
        {
            return xPos;
        }

        public void setXPos(int xPos)
        {
            xPos = xPos;
        }

        public int getYPos()
        {
            return yPos;
        }

        public void setYPos(int yPos)
        {
            yPos = yPos;
        }


    }
}
