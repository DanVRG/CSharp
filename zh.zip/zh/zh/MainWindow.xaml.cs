﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Timers;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace zh
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        List<Engiszik> population = new List<Engiszik>();

        int maxPopulation = 100;
        Random r = new Random();

        int closeDistance = 10;

        private static Timer timer;

        public MainWindow()
        {
            InitializeComponent();
            GeneratePopulation(maxPopulation);

            timer = new Timer(1000);
            timer.Elapsed += new ElapsedEventHandler(PopulationMoves);
            timer.Interval = 1000;
            timer.Enabled = true;
        }

        private void GeneratePopulation(int maxPopulation)
        {
            for (int i = 0; i < maxPopulation; i++)
            {
                int type = r.Next(100);
                Engiszik e;
                if (type < 67) //átlagosak
                {
                    int moodLevel = r.Next(101);
                    e = new Engiszik(i,"átlagos", moodLevel, 0,0);
                }
                else if (type >= 67 && type < 92) //optimisták
                {
                    int moodLevel = r.Next(60, 101);
                    e = new Engiszik(i, "optimista", moodLevel,0,0);
                }
                else //pesszimisták
                {
                    int moodLevel = r.Next(20);
                    e = new Engiszik(i, "pesszimista", moodLevel,0,0);
                }
                population.Add(e);
            }
        }

        private void PopulationMoves(object source, ElapsedEventArgs e)
        {
            //mozgatja az Engisziket
            int id = 0;
            foreach (Engiszik eng in population)
            {
                int x = r.Next(400);
                int y = r.Next(400);

                //ez sajnos nem működik
                /*
                Ellipse engiszki = new Ellipse();
                field.Children.Add(engiszki);
                engiszki.Name = id.ToString();
                Canvas.SetTop(engiszki, y);
                Canvas.SetTop(engiszki, x);
                id++;
                */

                eng.setXPos(x);
                eng.setYPos(y);
            }

            int moodLevelsData = 0;

            //közelségek ellenőrzése
            foreach (Engiszik eng in population)
            {
                if (eng.getType() == "pesszimista")
                {
                    foreach (Engiszik szomszedok in population)
                    {
                        if (eng.getID() != szomszedok.getID())
                        {
                            if (Math.Abs(eng.getXPos() - szomszedok.getXPos()) < closeDistance)
                            {
                                if (szomszedok.getType() == "optimista")
                                {
                                    eng.setMoodLevel((eng.getMoodLevel() / 2));
                                }
                            }
                            else if (Math.Abs(eng.getYPos() - szomszedok.getYPos()) < closeDistance)
                            {
                                if (szomszedok.getType() == "optimista")
                                {
                                    eng.setMoodLevel((eng.getMoodLevel() / 2));
                                }
                            }
                        }
                    }
                }
                else if (eng.getType() == "átlagos")
                {
                    foreach (Engiszik szomszedok in population)
                    {
                        if (eng.getID() != szomszedok.getID())
                        {
                            if (Math.Abs(eng.getXPos() - szomszedok.getXPos()) < closeDistance)
                            {
                                eng.setMoodLevel((eng.getMoodLevel()+szomszedok.getMoodLevel())/2);
                            }
                            else if (Math.Abs(eng.getYPos() - szomszedok.getYPos()) < closeDistance)
                            {
                                eng.setMoodLevel((eng.getMoodLevel() + szomszedok.getMoodLevel()) / 2);
                            }     
                        }
                    }
                }
                moodLevelsData += eng.getMoodLevel();
            }

            //eredmény kiirása
            moodLevels.Content = moodLevelsData.ToString();
        }


    }
}
